sed 's/unix/linux/' file_1.sh
echo
sed 's/unix/linux/2'  file_1.sh
echo
sed 's/unix/linux/g' file_1.sh
echo
sed 's/unix/linux/3g' file_1.sh
echo
sed '3 s/unix/linux/' file_1.sh
echo
sed 's/unix/linux/p' file_1.sh



